# Informe de pruebas — API Académica

| | |
|---|---|
| Estudiante | JUAN DIAZ|
| Fecha | 17 de octubre de 2026 |
| Versión probada | Rama `main`, último commit de código: `feat: add student endpoints` |
| Comando de inicio | `python -m uvicorn main:app --port 8000`, desde la carpeta de `main.py` |
| URL base | http://127.0.0.1:8000 |
| Herramientas | Swagger UI (capturas) y cliente HTTP en Python contra el servidor real (registros de texto) |
| Estado inicial | Base de pruebas vacía: `database.db` se borró antes de empezar |
| Datos | Ficticios |

**Resultado: 67 de 67 pruebas aprobadas, 0 fallidas.** Un `404` o `422` esperado cuenta como prueba aprobada.

## Procedimiento

1. Base nueva, Uvicorn iniciado y grupos P01 a P08 ejecutados en orden sobre la misma base. Los IDs inexistentes (`9999` y `999`) se verificaron como no registrados.
2. Tras los `422` del PUT se consultó de nuevo el curso (P04p) y se comparó la cantidad de cursos antes y después (P04c).
3. Persistencia (P09): se guardaron las listas, se detuvo Uvicorn con `Ctrl+C`, se inició de nuevo desde la misma carpeta y se compararon: idénticas. La salida de la terminal está en `evidencias/P09-terminal-uvicorn.txt`.
4. Integración (P09e, P09f): operar sobre cursos no cambia los estudiantes y viceversa.

Swagger no envía la petición cuando el ID no es entero (valida en el navegador), por eso los casos con `abc` en la ruta (P03c, P04r, P05f, P08c) se ejecutaron con el cliente HTTP y su evidencia es el registro de texto. Lo mismo ocurre con los casos de límites y de tipos inválidos que no tienen imagen: su evidencia es el registro de texto de su grupo.

## Resultados por caso

| Caso | Método y URL | Datos enviados | Descripción → esperado | Resultado obtenido | HTTP | Estado | Evidencia |
|---|---|---|---|---|---|---|---|
| P02a | `GET /courses` | — | Base vacía → 200 | `[]` | 200 | Aprobado | `P02-listar-cursos.txt`, `P02a-listar-cursos-vacio.png` |
| P07a | `GET /students` | — | Base vacía → 200 | `[]` | 200 | Aprobado | `P07-listar-estudiantes.txt`, `P07a-listar-estudiantes-vacio.png` |
| P01a | `POST /courses` | `{"name": "Desarrollo Web II", "credits": 3, "active": true}` | Curso válido → 201 | `{"id": 1, "name": "Desarrollo Web II", "credits": 3, "active": true}` | 201 | Aprobado | `P01-crear-curso.txt`, `P01a-crear-curso.png` |
| P01b | `POST /courses` | `{"name": "Redes", "credits": 3}` | Omitir active (queda true) → 201 | `{"id": 2, "name": "Redes", "credits": 3, "active": true}` | 201 | Aprobado | `P01-crear-curso.txt`, `P01b-crear-curso-sin-active.png` |
| P01c | `POST /courses` | `{"name": "Bases de Datos", "credits": 4, "active": false}` | active false → 201 | `{"id": 3, "name": "Bases de Datos", "credits": 4, "active": false}` | 201 | Aprobado | `P01-crear-curso.txt`, `P01c-crear-curso-active-false.png` |
| P01d | `POST /courses` | `{"name": "Abc", "credits": 1}` | Mínimos: nombre de 3, créditos 1 → 201 | `{"id": 4, "name": "Abc", "credits": 1, "active": true}` | 201 | Aprobado | `P01-crear-curso.txt` |
| P01e | `POST /courses` | `{"name": "<N × 80>", "credits": 6}` | Máximos: nombre de 80, créditos 6 → 201 | `{"id": 5, "name": "<N × 80>", "credits": 6, "active": true}` | 201 | Aprobado | `P01-crear-curso.txt` |
| P01f | `POST /courses` | `{"name": "Ab", "credits": 3}` | Nombre de 2 caracteres → 422 | error en `body.name` (string_too_short) | 422 | Aprobado | `P01-crear-curso.txt`, `P01f-nombre-2-caracteres.png` |
| P01g | `POST /courses` | `{"name": "<N × 81>", "credits": 3}` | Nombre de 81 caracteres → 422 | error en `body.name` (string_too_long) | 422 | Aprobado | `P01-crear-curso.txt` |
| P01h | `POST /courses` | `{"name": "Redes", "credits": 0}` | Créditos 0 → 422 | error en `body.credits` (greater_than_equal) | 422 | Aprobado | `P01-crear-curso.txt`, `P01h-creditos-0.png` |
| P01i | `POST /courses` | `{"name": "Redes", "credits": 7}` | Créditos 7 → 422 | error en `body.credits` (less_than_equal) | 422 | Aprobado | `P01-crear-curso.txt`, `P01i-creditos-7.png` |
| P01j | `POST /courses` | `{"credits": 3}` | Omitir name → 422 | error en `body.name` (missing) | 422 | Aprobado | `P01-crear-curso.txt` |
| P01k | `POST /courses` | `{"name": "Redes"}` | Omitir credits → 422 | error en `body.credits` (missing) | 422 | Aprobado | `P01-crear-curso.txt` |
| P01l | `POST /courses` | `{"name": "Redes", "credits": "abc"}` | credits = "abc" → 422 | error en `body.credits` (int_parsing) | 422 | Aprobado | `P01-crear-curso.txt` |
| P01m | `POST /courses` | `{"name": "Redes", "credits": 3, "active": "invalido"}` | active = "invalido" → 422 | error en `body.active` (bool_parsing) | 422 | Aprobado | `P01-crear-curso.txt` |
| P02b | `GET /courses` | — | Varios cursos, activos e inactivos → 200 | lista de 5 registro(s) | 200 | Aprobado | `P02-listar-cursos.txt`, `P02b-listar-cursos.png` |
| P03a | `GET /courses/1` | — | ID existente → 200 | `{"id": 1, "name": "Desarrollo Web II", "credits": 3, "active": true}` | 200 | Aprobado | `P03-consultar-curso.txt`, `P03a-consultar-curso.png` |
| P03b | `GET /courses/9999` | — | ID inexistente → 404 | `{"detail": "Course not found"}` | 404 | Aprobado | `P03-consultar-curso.txt`, `P03b-curso-inexistente.png` |
| P03c | `GET /courses/abc` | — | ID no entero → 422 | error en `path.course_id` (int_parsing) | 422 | Aprobado | `P03-consultar-curso.txt` |
| P04a | `PUT /courses/1` | `{"name": "Programación II", "credits": 4, "active": false}` | PUT válido: mismo ID, active true → false → 200 | `{"id": 1, "name": "Programación II", "credits": 4, "active": false}` | 200 | Aprobado | `P04-actualizar-curso.txt`, `P04a-put-valido.png` |
| P04b | `GET /courses/1` | — | GET posterior al PUT → 200 | `{"id": 1, "name": "Programación II", "credits": 4, "active": false}` | 200 | Aprobado | `P04-actualizar-curso.txt`, `P04b-despues-update.png` |
| P04c | `GET /courses` antes y después del PUT | — | Cantidad de cursos antes y después del PUT | `{"antes": 5, "despues": 5}` | 200 | Aprobado | `P04-actualizar-curso.txt` |
| P04d | `PUT /courses/1` | `{"name": "Abc", "credits": 1, "active": true}` | Límites mínimos válidos → 200 | `{"id": 1, "name": "Abc", "credits": 1, "active": true}` | 200 | Aprobado | `P04-actualizar-curso.txt` |
| P04e | `PUT /courses/1` | `{"name": "<N × 80>", "credits": 6, "active": true}` | Límites máximos válidos → 200 | `{"id": 1, "name": "<N × 80>", "credits": 6, "active": true}` | 200 | Aprobado | `P04-actualizar-curso.txt` |
| P04f | `PUT /courses/1` | `{"name": "Programación II", "credits": 4, "active": false}` | Restaurar valores → 200 | `{"id": 1, "name": "Programación II", "credits": 4, "active": false}` | 200 | Aprobado | `P04-actualizar-curso.txt` |
| P04g | `PUT /courses/1` | `{"name": "Programación II", "credits": 0, "active": true}` | Créditos 0 → 422 | error en `body.credits` (greater_than_equal) | 422 | Aprobado | `P04-actualizar-curso.txt`, `P04g-put-creditos-0.png` |
| P04h | `PUT /courses/1` | `{"name": "Programación II", "credits": 7, "active": true}` | Créditos 7 → 422 | error en `body.credits` (less_than_equal) | 422 | Aprobado | `P04-actualizar-curso.txt` |
| P04i | `PUT /courses/1` | `{"name": "Ab", "credits": 3, "active": true}` | Nombre de 2 caracteres → 422 | error en `body.name` (string_too_short) | 422 | Aprobado | `P04-actualizar-curso.txt`, `P04i-put-nombre-2-caracteres.png` |
| P04j | `PUT /courses/1` | `{"name": "<N × 81>", "credits": 3, "active": true}` | Nombre de 81 caracteres → 422 | error en `body.name` (string_too_long) | 422 | Aprobado | `P04-actualizar-curso.txt` |
| P04k | `PUT /courses/1` | `{"credits": 3, "active": true}` | Omitir name → 422 | error en `body.name` (missing) | 422 | Aprobado | `P04-actualizar-curso.txt` |
| P04l | `PUT /courses/1` | `{"name": "Programación II", "active": true}` | Omitir credits → 422 | error en `body.credits` (missing) | 422 | Aprobado | `P04-actualizar-curso.txt` |
| P04m | `PUT /courses/1` | `{"name": "Programación II", "credits": 3}` | Omitir active → 422 | error en `body.active` (missing) | 422 | Aprobado | `P04-actualizar-curso.txt`, `P04m-put-sin-active.png` |
| P04n | `PUT /courses/1` | `{"name": "Programación II", "credits": "abc", "active": true}` | credits = "abc" → 422 | error en `body.credits` (int_parsing) | 422 | Aprobado | `P04-actualizar-curso.txt` |
| P04o | `PUT /courses/1` | `{"name": "Programación II", "credits": 3, "active": "invalido"}` | active = "invalido" → 422 | error en `body.active` (bool_parsing) | 422 | Aprobado | `P04-actualizar-curso.txt` |
| P04p | `GET /courses/1` | — | El curso conserva sus valores tras los 422 → 200 | `{"id": 1, "name": "Programación II", "credits": 4, "active": false}` | 200 | Aprobado | `P04-actualizar-curso.txt` |
| P04q | `PUT /courses/9999` | `{"name": "Programación II", "credits": 4, "active": false}` | ID inexistente con cuerpo válido → 404 | `{"detail": "Course not found"}` | 404 | Aprobado | `P04-actualizar-curso.txt`, `P04q-put-id-inexistente.png` |
| P04r | `PUT /courses/abc` | `{"name": "Programación II", "credits": 4, "active": false}` | ID no entero → 422 | error en `path.course_id` (int_parsing) | 422 | Aprobado | `P04-actualizar-curso.txt` |
| P05a | `DELETE /courses/2` | — | Eliminar curso existente → 200 | `{"message": "Course deleted"}` | 200 | Aprobado | `P05-eliminar-curso.txt`, `P05a-delete.png` |
| P05b | `GET /courses/2` | — | GET posterior al DELETE → 404 | `{"detail": "Course not found"}` | 404 | Aprobado | `P05-eliminar-curso.txt`, `P05b-consulta-posterior.png` |
| P05c | `GET /courses` | — | Lista sin el eliminado y con los demás → 200 | lista de 4 registro(s) | 200 | Aprobado | `P05-eliminar-curso.txt`, `P05c-lista-sin-eliminado.png` |
| P05d | `DELETE /courses/2` | — | Repetir el DELETE → 404 | `{"detail": "Course not found"}` | 404 | Aprobado | `P05-eliminar-curso.txt`, `P05d-delete-repetido.png` |
| P05e | `DELETE /courses/9999` | — | ID inexistente → 404 | `{"detail": "Course not found"}` | 404 | Aprobado | `P05-eliminar-curso.txt` |
| P05f | `DELETE /courses/abc` | — | ID no entero → 422 | error en `path.course_id` (int_parsing) | 422 | Aprobado | `P05-eliminar-curso.txt` |
| P06a | `POST /students` | `{"name": "Ana Pérez", "email": "ana@universidad.edu", "semester": 4}` | Estudiante válido, active omitido (true) → 201 | `{"id": 1, "name": "Ana Pérez", "email": "ana@universidad.edu", "semester": 4, "active": true}` | 201 | Aprobado | `P06-crear-estudiante.txt`, `P06a-crear-estudiante.png` |
| P06b | `POST /students` | `{"name": "Luis Gómez", "email": "luis@universidad.edu", "semester": 2, "active": false}` | active false → 201 | `{"id": 2, "name": "Luis Gómez", "email": "luis@universidad.edu", "semester": 2, "active": false}` | 201 | Aprobado | `P06-crear-estudiante.txt`, `P06b-estudiante-active-false.png` |
| P06c | `POST /students` | `{"name": "Abc", "email": "abc@universidad.edu", "semester": 1}` | Mínimos: nombre de 3, semestre 1 → 201 | `{"id": 3, "name": "Abc", "email": "abc@universidad.edu", "semester": 1, "active": true}` | 201 | Aprobado | `P06-crear-estudiante.txt` |
| P06d | `POST /students` | `{"name": "<N × 80>", "email": "n@universidad.edu", "semester": 10}` | Máximos: nombre de 80, semestre 10 → 201 | `{"id": 4, "name": "<N × 80>", "email": "n@universidad.edu", "semester": 10, "active": true}` | 201 | Aprobado | `P06-crear-estudiante.txt` |
| P06e | `POST /students` | `{"name": "Ab", "email": "ana@universidad.edu", "semester": 4}` | Nombre de 2 caracteres → 422 | error en `body.name` (string_too_short) | 422 | Aprobado | `P06-crear-estudiante.txt`, `P06e-nombre-2-caracteres.png` |
| P06f | `POST /students` | `{"name": "<N × 81>", "email": "ana@universidad.edu", "semester": 4}` | Nombre de 81 caracteres → 422 | error en `body.name` (string_too_long) | 422 | Aprobado | `P06-crear-estudiante.txt` |
| P06g | `POST /students` | `{"name": "Ana Pérez", "email": "ana@universidad.edu", "semester": 0}` | Semestre 0 → 422 | error en `body.semester` (greater_than_equal) | 422 | Aprobado | `P06-crear-estudiante.txt`, `P06g-semestre-0.png` |
| P06h | `POST /students` | `{"name": "Ana Pérez", "email": "ana@universidad.edu", "semester": 11}` | Semestre 11 → 422 | error en `body.semester` (less_than_equal) | 422 | Aprobado | `P06-crear-estudiante.txt`, `P06h-semestre-11.png` |
| P06i | `POST /students` | `{"name": "Ana Pérez", "email": "", "semester": 4}` | Email vacío → 422 | error en `body.email` (string_too_short) | 422 | Aprobado | `P06-crear-estudiante.txt`, `P06i-email-vacio.png` |
| P06j | `POST /students` | `{"email": "ana@universidad.edu", "semester": 4}` | Omitir name → 422 | error en `body.name` (missing) | 422 | Aprobado | `P06-crear-estudiante.txt` |
| P06k | `POST /students` | `{"name": "Ana Pérez", "semester": 4}` | Omitir email → 422 | error en `body.email` (missing) | 422 | Aprobado | `P06-crear-estudiante.txt` |
| P06l | `POST /students` | `{"name": "Ana Pérez", "email": "ana@universidad.edu"}` | Omitir semester → 422 | error en `body.semester` (missing) | 422 | Aprobado | `P06-crear-estudiante.txt` |
| P06m | `POST /students` | `{"name": "Ana Pérez", "email": "ana@universidad.edu", "semester": "abc"}` | semester = "abc" → 422 | error en `body.semester` (int_parsing) | 422 | Aprobado | `P06-crear-estudiante.txt` |
| P06n | `POST /students` | `{"name": "Ana Pérez", "email": "ana@universidad.edu", "semester": 4, "active": "invalido"}` | active = "invalido" → 422 | error en `body.active` (bool_parsing) | 422 | Aprobado | `P06-crear-estudiante.txt` |
| P07b | `GET /students` | — | Varios estudiantes, activos e inactivos → 200 | lista de 4 registro(s) | 200 | Aprobado | `P07-listar-estudiantes.txt`, `P07b-listar-estudiantes.png` |
| P08a | `GET /students/1` | — | ID existente → 200 | `{"id": 1, "name": "Ana Pérez", "email": "ana@universidad.edu", "semester": 4, "active": true}` | 200 | Aprobado | `P08-consultar-estudiante.txt`, `P08a-consultar-estudiante.png` |
| P08b | `GET /students/999` | — | ID inexistente → 404 | `{"detail": "Student not found"}` | 404 | Aprobado | `P08-consultar-estudiante.txt`, `P08b-estudiante-inexistente.png` |
| P08c | `GET /students/abc` | — | ID no entero → 422 | error en `path.student_id` (int_parsing) | 422 | Aprobado | `P08-consultar-estudiante.txt` |
| P09a | `GET /courses` | — | Cursos tras reiniciar Uvicorn → 200 | lista de 4 registro(s) | 200 | Aprobado | `P09-persistencia-integracion.txt`, `P09a-despues-reinicio-cursos.png` |
| P09b | `GET /students` | — | Estudiantes tras reiniciar Uvicorn → 200 | lista de 4 registro(s) | 200 | Aprobado | `P09-persistencia-integracion.txt`, `P09b-despues-reinicio-estudiantes.png` |
| P09c | `GET /courses/1` | — | Cambios del PUT permanecen → 200 | `{"id": 1, "name": "Programación II", "credits": 4, "active": false}` | 200 | Aprobado | `P09-persistencia-integracion.txt`, `P09c-put-permanece.png` |
| P09d | `GET /courses/2` | — | Curso eliminado sigue ausente → 404 | `{"detail": "Course not found"}` | 404 | Aprobado | `P09-persistencia-integracion.txt`, `P09d-eliminado-sigue-ausente.png` |
| P09e | `GET /students` antes y después | — | POST, PUT y DELETE de cursos no alteran los estudiantes | `{"estudiantes_antes": 4, "estudiantes_despues": 4, "iguales": true}` | 200 | Aprobado | `P09-persistencia-integracion.txt` |
| P09f | `GET /courses` antes y después | — | POST de estudiantes no altera los cursos | `{"cursos_antes": 4, "cursos_despues": 4, "iguales": true}` | 200 | Aprobado | `P09-persistencia-integracion.txt` |

## Capturas de Swagger

Cada captura muestra la petición enviada y la sección *Server response* con el código y el cuerpo reales. Las imágenes P04-antes, P05-antes y P09-antes-* muestran el estado previo a la operación que se prueba.

### P02 — Listar cursos

**P02a** (HTTP 200)

![P02a](evidencias/P02a-listar-cursos-vacio.png)


### P01 — Crear cursos

**P01a** (HTTP 201)

![P01a](evidencias/P01a-crear-curso.png)

**P01b** (HTTP 201)

![P01b](evidencias/P01b-crear-curso-sin-active.png)

**P01c** (HTTP 201)

![P01c](evidencias/P01c-crear-curso-active-false.png)

**P01f** (HTTP 422)

![P01f](evidencias/P01f-nombre-2-caracteres.png)

**P01h** (HTTP 422)

![P01h](evidencias/P01h-creditos-0.png)

**P01i** (HTTP 422)

![P01i](evidencias/P01i-creditos-7.png)


### P02 — Listar cursos

**P02b** (HTTP 200)

![P02b](evidencias/P02b-listar-cursos.png)


### P03 — Consultar curso

**P03a** (HTTP 200)

![P03a](evidencias/P03a-consultar-curso.png)

**P03b** (HTTP 404)

![P03b](evidencias/P03b-curso-inexistente.png)


### P04 — Actualizar curso

**P04-antes** (HTTP 200)

![P04-antes](evidencias/P04-antes-antes-update.png)

**P04a** (HTTP 200)

![P04a](evidencias/P04a-put-valido.png)

**P04b** (HTTP 200)

![P04b](evidencias/P04b-despues-update.png)

**P04g** (HTTP 422)

![P04g](evidencias/P04g-put-creditos-0.png)

**P04i** (HTTP 422)

![P04i](evidencias/P04i-put-nombre-2-caracteres.png)

**P04m** (HTTP 422)

![P04m](evidencias/P04m-put-sin-active.png)

**P04q** (HTTP 404)

![P04q](evidencias/P04q-put-id-inexistente.png)


### P05 — Eliminar curso

**P05-antes** (HTTP 200)

![P05-antes](evidencias/P05-antes-antes-delete.png)

**P05a** (HTTP 200)

![P05a](evidencias/P05a-delete.png)

**P05b** (HTTP 404)

![P05b](evidencias/P05b-consulta-posterior.png)

**P05c** (HTTP 200)

![P05c](evidencias/P05c-lista-sin-eliminado.png)

**P05d** (HTTP 404)

![P05d](evidencias/P05d-delete-repetido.png)


### P07 — Listar estudiantes

**P07a** (HTTP 200)

![P07a](evidencias/P07a-listar-estudiantes-vacio.png)


### P06 — Crear estudiantes

**P06a** (HTTP 201)

![P06a](evidencias/P06a-crear-estudiante.png)

**P06b** (HTTP 201)

![P06b](evidencias/P06b-estudiante-active-false.png)

**P06e** (HTTP 422)

![P06e](evidencias/P06e-nombre-2-caracteres.png)

**P06g** (HTTP 422)

![P06g](evidencias/P06g-semestre-0.png)

**P06h** (HTTP 422)

![P06h](evidencias/P06h-semestre-11.png)

**P06i** (HTTP 422)

![P06i](evidencias/P06i-email-vacio.png)


### P07 — Listar estudiantes

**P07b** (HTTP 200)

![P07b](evidencias/P07b-listar-estudiantes.png)


### P08 — Consultar estudiante

**P08a** (HTTP 200)

![P08a](evidencias/P08a-consultar-estudiante.png)

**P08b** (HTTP 404)

![P08b](evidencias/P08b-estudiante-inexistente.png)


### P09 — Persistencia tras reiniciar

**P09-antes-cursos** (HTTP 200)

![P09-antes-cursos](evidencias/P09-antes-cursos-antes-reinicio-cursos.png)

**P09-antes-estudiantes** (HTTP 200)

![P09-antes-estudiantes](evidencias/P09-antes-estudiantes-antes-reinicio-estudiantes.png)

**P09a** (HTTP 200)

![P09a](evidencias/P09a-despues-reinicio-cursos.png)

**P09b** (HTTP 200)

![P09b](evidencias/P09b-despues-reinicio-estudiantes.png)

**P09c** (HTTP 200)

![P09c](evidencias/P09c-put-permanece.png)

**P09d** (HTTP 404)

![P09d](evidencias/P09d-eliminado-sigue-ausente.png)


## Observaciones

- El `id` no forma parte de `CourseUpdate`: el único ID válido es el de la URL. La cantidad de cursos no cambió con el PUT (P04c).
- Los `422` no crearon ni modificaron registros (P04p y las listas de P05c, P07b y P09).
- Del email solo se valida que no esté vacío; el formato y la unicidad no están implementados y no se probaron.
